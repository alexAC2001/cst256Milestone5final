<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 27th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/profile', function() {return view('profile');});


// To display all users for an admin
Route::get('users', 'UsersController@index')->name('users.index');

// To delete a user
Route::delete('users/{id}', 'UsersController@destroy')->name('users.destroy');

// For an Admin to edit a job
//Route::get('jobs/edit', 'JobsController@edit')->name('jobs.edit');

// To go to a job posting page
Route::get('jobs', 'JobsController@jobs')->name('jobs.index');


Route::get('jobs/create', 'JobsController@create')->name('jobs.create');
//Route::get('jobs/{id}', 'JobsController@show');
Route::post('jobs', 'JobsController@store');

// This route is to call the edit function to return the edit view page
Route::get('jobs/{id}/edit', 'JobsController@edit')->name('jobs.edit');

// This route is to call the update function to perform the changes in the database
Route::put('jobs/{id}', 'JobsController@update')->name('jobs.update');

// This route is for deleting a job
Route::delete('jobs/{id}', 'JobsController@destroy')->name('jobs.destroy');
// LIST
Route::get('jobslist', 'JobsController@list')->name('jobs.list');


// To update/edit profile
Route::get('users/profile', 'UsersController@edit')->name('users.edit-profile');  

// To update profile in db
Route::put('users/profile', 'UsersController@update')->name('users.update-profile'); 
  
// For Portfolio
Route::get('users/portfolio', 'UsersController@portfolio')->name('users.portfolio');
Route::put('users/portfolio', 'UsersController@uploadPortfolio')->name('users.upload-portfolio');
Route::get('users/otherPortfolios', 'UsersController@otherPortfolios')->name('otherPortfolios');

//------------------------- For Affinity Groups --------------------------------\\
// For Admin to view all groups
Route::get('groups', 'GroupsController@index')->name('groups.index');
// For Admin to create a group
Route::get('groups/create', 'GroupsController@create')->name('groups.create');
// Store the values entered
Route::post('groups', 'GroupsController@store');
// For Admin to edit an existing group
Route::get('groups/{id}/edit', 'GroupsController@edit')->name('groups.edit');
// This route is to call the update function to perform the changes in the database
Route::put('groups/{id}', 'GroupsController@update')->name('groups.update');
// This route is for deleting a group
Route::delete('groups/{id}', 'GroupsController@destroy')->name('groups.destroy');

// To view all affinity groups
Route::get('groupslist', 'GroupsController@list')->name('groups.list');

// This route is for joining a group
Route::post('groupslist/{id}/joinGroup', 'GroupsController@joinGroup')->name('groups.joinGroup');

// This route is for leaving a group
Route::post('groupslist/{id}/leaveGroup', 'GroupsController@leaveGroup')->name('groups.leaveGroup');


// This is for the security.
// This will make sure the user is authenticated and is an admin
Route::middleware(['auth', 'admin'])->group(function (){
    
    Route::get('users', 'UsersController@index')->name('users.index');    
    Route::get('jobs', 'JobsController@jobs')->name('jobs.index');
    Route::get('jobs/create', 'JobsController@create')->name('jobs.create');
    Route::get('groups', 'GroupsController@index')->name('groups.index');
    Route::get('groups/create', 'GroupsController@create')->name('groups.create');
    // Make a user an admin
    Route::post('users/{user}/make-admin', 'UsersController@makeAdmin')->name('users.make-admin');
    
});
/*Route::middleware(['auth', 'writer'])->group(function (){
        
        //Route::get('users/portfolio', 'UsersController@portfolio')->name('users.portfolio');
          Route::get('jobs', 'JobsController@index')->name('jobs.index');        
        // Make a user an admin
       // Route::post('users/{user}/make-admin', 'UsersController@makeAdmin')->name('users.make-admin');        
});*/
