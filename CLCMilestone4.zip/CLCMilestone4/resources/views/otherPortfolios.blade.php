<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 21th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

?>

@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')

<div class="card card-default">
	
	<div class="card-header">User Portfolios</div>
	
	
	<div class="card-body">
	
		@if($users->count() > 0)
		
			<table class="table">
			
				<thead>
				
					<th>Image</th>
					
					<th>Name</th>
					
					<th>List of Jobs</th>
					
					<th>Skills</th>
					
					<th>Education</th>
					
					<th>Contact Info</th>
					
					</thead>
					
					<tbody>
					
						@foreach($users as $user)
						
					    	<tr>
										
    						    <td>
    						    
    						    {{ $user->image }}
    						    
    						    </td>
    						    
    						    <td>
    						    
    						    {{ $user->name }}
    						    
    						    </td>
    						    
    						    <td>
    						    
    						    {{ $user->jobHistory }}
    						    
    						    </td>
    						    
    						    <td>
    						    
    						    {{ $user->skill }}
    						    
    						    </td>
    						    
    						    <td>
    						    
    						    {{ $user->education }}
    						    
    						    </td>
    						    
    						    <td>
    						    
    						    {{ $user->email }}
    						    <br></br>
    						    {{ $user->phoneNumber }}
    						    
    						    </td>

						    </tr>
						    
						 @endforeach						 
					
					</tbody>			
			
			</table>
			
		@else
			
			<h3 class="text-center">No Other Portfolios Yet</h3>
			
		@endif
		
	</div>
	
</div>

@endsection
			